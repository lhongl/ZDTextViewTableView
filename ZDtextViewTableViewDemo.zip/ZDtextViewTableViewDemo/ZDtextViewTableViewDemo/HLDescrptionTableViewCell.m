//
//  HLDescrptionTableViewCell.m
//  HLToaster
//
//  Created by WeiDang on 16/6/28.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "HLDescrptionTableViewCell.h"
#define SCREEN_WIDTH    [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT   [[UIScreen mainScreen] bounds].size.height
/**
 *  16进制颜色
 */
#define HLHEXCOLOR(str) [UIColor colorWithHexString:str]
@interface HLDescrptionTableViewCell ()

@end
@implementation HLDescrptionTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.MyTextView = [[ZDTextView alloc] initWithFrame:CGRectMake(8, 5, SCREEN_WIDTH - 16, 30)];
        _MyTextView.textColor = [UIColor blackColor];
        _MyTextView.font = [UIFont systemFontOfSize:14];
        _MyTextView.placeholder = @"请再次输入您的信息";
        _MyTextView.isCanExtend = YES;
        _MyTextView.extendLimitRow = 10;
        /** 伸缩方向 */
        _MyTextView.extendDirection = ExtendDown;
        _MyTextView.backgroundColor = [UIColor clearColor];
        _MyTextView.layer.borderWidth = 1;
        [self.contentView addSubview:_MyTextView];
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
