//
//  ViewController.m
//  ZDtextViewTableViewDemo
//
//  Created by WeiDang on 16/7/2.
//  Copyright © 2016年 ZhangDan. All rights reserved.
//

#import "ViewController.h"
#import "HLDescrptionTableViewCell.h"
@interface ViewController ()<UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *MytableView;
@property (strong, nonatomic) NSMutableArray * cellHeightArray;

@end

@implementation ViewController
- (NSMutableArray *)cellHeightArray
{
    if (!_cellHeightArray) {
        _cellHeightArray = [[NSMutableArray array]init];
    }
    return _cellHeightArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.MytableView registerClass:[HLDescrptionTableViewCell class] forCellReuseIdentifier:@"HLDescrptionTableViewCell"];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(change:) name:@"changeCellHeight" object:nil];
    _cellHeightArray = [NSMutableArray arrayWithArray:@[@"50", @"50", @"50", @"50", @"50"]];
    
}
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:@"changeCellHeight" object:nil];
}
- (void)change:(NSNotification *)noti
{
     NSArray * array  =  [noti object];
    [self.MytableView beginUpdates];
    [_cellHeightArray replaceObjectAtIndex:[array[1] integerValue] withObject:array[0]];
    [self.MytableView endUpdates];

}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _cellHeightArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HLDescrptionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HLDescrptionTableViewCell"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.MyTextView.tag = indexPath.row;
    return cell;

}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [_cellHeightArray[indexPath.row] floatValue]+10;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
