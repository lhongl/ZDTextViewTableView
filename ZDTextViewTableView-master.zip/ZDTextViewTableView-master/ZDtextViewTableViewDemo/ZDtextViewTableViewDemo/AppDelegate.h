//
//  AppDelegate.h
//  ZDtextViewTableViewDemo
//
//  Created by WeiDang on 16/7/2.
//  Copyright © 2016年 ZhangDan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

