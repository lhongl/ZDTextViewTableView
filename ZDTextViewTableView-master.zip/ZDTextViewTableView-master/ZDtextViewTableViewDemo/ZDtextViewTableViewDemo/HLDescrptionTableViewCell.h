//
//  HLDescrptionTableViewCell.h
//  HLToaster
//
//  Created by WeiDang on 16/6/28.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZDTextView.h"
@interface HLDescrptionTableViewCell : UITableViewCell<ZDTextViewDelegate>
@property (nonatomic, strong) ZDTextView *MyTextView;
@end
